<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?php echo e(asset('storage/' . $userStore->store_logo)); ?>" type="image/x-icon">
    <title><?php echo e($userStore->store_name ?? 'E-Katalog Fashion'); ?></title>

    <meta name="description" content="Demo katalog fashion dengan koleksi lengkap pakaian dan aksesoris terkini">
    <meta name="keywords" content="fashion, clothing, style, trends, catalog, online shopping, apparel, accessories">
    <meta name="author" content="Fashion E-Catalog Demo">
    <meta name="robots" content="index, follow">

    <meta property="og:title" content="Fashion E-Catalog Demo">
    <meta property="og:description" content="Demo katalog fashion dengan koleksi lengkap pakaian dan aksesoris terkini">
    <meta property="og:type" content="website">
    <meta property="og:image" content="images/og-image.jpg">

    <link rel="icon" type="image/x-icon" href="../favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('assets/demo/fashion/style.css')); ?>">
</head>

<body>
    <nav class="navbar">
        <div class="nav-container">
            <a href="<?php echo e(url('/')); ?>" class="nav-brand">
                <div class="brand-icon">
                    <?php if($userStore && $userStore->store_logo): ?>
                        <img class="brand-logo" src="<?php echo e(asset('storage/' . $userStore->store_logo)); ?>"
                            alt="<?php echo e($userStore->store_name ?? 'Store Logo'); ?>" loading="lazy" decoding="async">
                    <?php else: ?>
                        <img class="brand-logo" src="<?php echo e(asset('assets/demo/fashion/img/temp/logo-fashion.png')); ?>"
                            alt="<?php echo e($userStore->store_name ?? 'Fashion Store Logo'); ?>" loading="lazy" decoding="async">
                    <?php endif; ?>
                </div>
                <span class="brand-text"><?php echo e($userStore->store_name ?? 'Fashion Store'); ?></span>
            </a>
            <div class="nav-actions">
            </div>
        </div>
    </nav>

    <style>
        .brand-logo {
            height: 40px;
            width: 40px;
            object-fit: contain;
        }

        @media (min-width: 640px) {
            .brand-logo {
                height: 50px;
                width: 50px;
            }
        }
    </style>

    <section class="hero">
        <div class="slider-container" id="slider-container">
            <div class="slider-wrapper" id="slider-wrapper">
                <div class="slide"
                    style="background: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url('https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'); background-size: cover; background-position: center; background-repeat: no-repeat;">
                </div>
                <div class="slide"
                    style="background: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url('https://images.unsplash.com/photo-1445205170230-053b83016050?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2071&q=80'); background-size: cover; background-position: center; background-repeat: no-repeat;">
                </div>
                <div class="slide"
                    style="background: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url('https://images.unsplash.com/photo-1483985988355-763728e1935b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'); background-size: cover; background-position: center; background-repeat: no-repeat;">
                </div>
            </div>
        </div>

        <button class="slider-nav prev">
            <svg viewBox="0 0 24 24">
                <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z" />
            </svg>
        </button>
        <button class="slider-nav next">
            <svg viewBox="0 0 24 24">
                <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z" />
            </svg>
        </button>

        <div class="slider-indicators" id="slider-indicators">
            <div class="slider-indicator active"></div>
            <div class="slider-indicator"></div>
            <div class="slider-indicator"></div>
        </div>

        <div class="hero-content">
            <h1 class="hero-title">Katalog Fashion</h1>
            <p class="hero-subtitle">Dimana Setiap Benang Menceritakan Kisah, dan Setiap Kisah Memiliki Arti</p>
        </div>
    </section>

    <main class="container">
        <section class="section">
            <div class="section-title">
                <h2>Kategori</h2>
                <p>Pilih kategori produk yang Anda inginkan</p>
            </div>

            <div class="category-grid" id="categoryGrid">
                <div class="category-card active" data-category-id="all">
                    <div class="category-name">Semua Produk</div>
                    <div class="category-description">Lihat semua produk yang tersedia</div>
                </div>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="category-card" data-category-id="<?php echo e($category->id); ?>">
                        <div class="category-name"><?php echo e($category->name); ?></div>
                        <div class="category-description"><?php echo e($category->description); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <div class="subcategory-section" id="subcategorySection" style="display: none;">
                <div class="section-title">
                    <h3>Sub Kategori</h3>
                    <p>Pilih sub kategori untuk filter lebih spesifik</p>
                </div>
                <div class="subcategory-grid" id="subcategoryGrid">
                    
                </div>
            </div>

            <div id="searchContainer" class="search-container">
                <div class="search-and-filters-wrapper">
                    <div class="search-wrapper">
                        <input type="text" id="searchInput" placeholder="Cari produk...">
                    </div>

                    <div class="filters-section">
                        <div class="filter-group">
                            <label for="sortPrice">Urutkan Harga:</label>
                            <select id="sortPrice">
                                <option value="">-- Pilih --</option>
                                <option value="low-high">Harga Terendah</option>
                                <option value="high-low">Harga Tertinggi</option>
                            </select>
                        </div>

                        <div class="filter-group">
                            <label for="sortName">Urutkan Nama:</label>
                            <select id="sortName">
                                <option value="">-- Pilih --</option>
                                <option value="a-z">A - Z</option>
                                <option value="z-a">Z - A</option>
                            </select>
                        </div>

                        <div class="filter-group">
                            <label for="sortDate">Urutkan Tanggal:</label>
                            <select id="sortDate">
                                <option value="">-- Pilih --</option>
                                <option value="newest">Terbaru</option>
                                <option value="oldest">Terlama</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="section">
            <div class="section-title">
                <h2>Semua Produk</h2>
                <p>Jelajahi koleksi lengkap kami</p>
            </div>

            
            <div class="products-grid" id="productsGrid">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $imagePath = $product->image ?? ($product->productImages->first()->image_path ?? null);
                        $imageUrl = $imagePath
                            ? url('tenancy/assets') . '/' . trim($imagePath, '/')
                            : 'https://via.placeholder.com/200?text=No+Image';
                        $formattedPrice = 'Rp ' . number_format($product->price, 0, ',', '.');
                    ?>
                    <div class="product-card" data-product-id="<?php echo e($product->id); ?>"
                        onclick="showProductDetails(<?php echo e($product->id); ?>)">
                        <div class="product-image">
                            <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($product->name); ?>" loading="lazy"
                                onerror="this.onerror=null; this.src='https://via.placeholder.com/200?text=No+Image'; this.style.opacity='1';"
                                onload="this.style.opacity='1';" style="opacity: 0; transition: opacity 0.3s ease;">
                        </div>
                        <div class="product-info">
                            <div class="product-category"><?php echo e($product->category->name ?? 'Uncategorized'); ?></div>
                            <div class="product-name"><?php echo e($product->name); ?></div>
                            <div class="product-price"><?php echo e($formattedPrice); ?></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    
                    <div id="noResults" class="no-results" style="display: block; grid-column: 1 / -1;">
                        <h3>Produk yang Anda cari tidak ditemukan</h3>
                        <p>Coba gunakan kata kunci yang berbeda atau lihat semua produk kami.</p>
                    </div>
                <?php endif; ?>
            </div>

            
            <div class="pagination-links">
                <?php echo e($products->appends(request()->query())->links()); ?>

            </div>
        </section>

    </main>

    <style>
        /* Style untuk pagination */
        .pagination-links {
            margin-top: 2rem;
            display: flex;
            justify-content: center;
        }

        .pagination {
            display: flex;
            list-style: none;
            padding: 0;
        }

        .pagination li {
            margin: 0 5px;
        }

        .pagination li a,
        .pagination li span {
            display: block;
            padding: 8px 12px;
            border: 1px solid #ddd;
            color: #333;
            text-decoration: none;
            border-radius: 4px;
        }

        .pagination li.active span {
            background-color: #333;
            color: #fff;
            border-color: #333;
        }

        .pagination li.disabled span {
            color: #aaa;
            background-color: #f5f5f5;
        }
    </style>

    <footer class="footer">
        <div class="footer-content">
            <div class="footer-left-content">
                <div class="footer-logo-section">
                    <div class="footer-brand-container">
                        <?php if($userStore && $userStore->store_logo): ?>
                            <img class="footer-logo" src="<?php echo e(asset('storage/' . $userStore->store_logo)); ?>"
                                alt="<?php echo e($userStore->store_name ?? 'Store Logo'); ?>" loading="lazy" decoding="async">
                        <?php else: ?>
                            <img class="footer-logo"
                                src="<?php echo e(asset('assets/demo/fashion/img/temp/logo-fashion.png')); ?>"
                                alt="<?php echo e($userStore->store_name ?? 'Fashion Store Logo'); ?>" loading="lazy"
                                decoding="async">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="footer-section footer-text-content">
                    <h3><?php echo e($userStore->store_name ?? 'Fashion Store'); ?></h3>
                    <p><?php echo e($userStore->store_description ?? 'A place to find your best fashion.'); ?></p>
                </div>
            </div>
            <div class="footer-middle-space">
            </div>
            <div class="footer-section footer-contact">
                <h3>Informasi Kontak</h3>
                <div class="contact-item">
                    <i class="contact-icon">📞</i>
                    <span><?php echo e($userStore->store_phone ?? 'Nomor Telepon Tidak Tersedia'); ?></span>
                </div>
                <div class="contact-item">
                    <i class="contact-icon">✉</i>
                    <span><?php echo e($userStore->store_email ?? 'Alamat Email Tidak Tersedia'); ?></span>
                </div>
                <div class="contact-item">
                    <i class="contact-icon">📍</i>
                    <span><?php echo e($userStore->store_address ?? 'Alamat Tidak Tersedia'); ?></span>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2024 Powered by PT. Era Cipta Digital</p>
        </div>
    </footer>

    <style>
        .footer-brand-container {
            height: 50px;
            width: 50px;
        }

        .footer-logo {
            height: 100%;
            width: 100%;
            object-fit: contain;
        }

        /* Style untuk gambar produk */
        .product-image {
            position: relative;
            width: 100%;
            height: 200px;
            overflow: hidden;
            border-radius: 8px;
            background: #f8f9fa;
        }

        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: opacity 0.3s ease;
        }

        .no-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f5f5f5;
            color: #666;
            font-size: 1rem;
            border-radius: 8px;
        }

        .modal-product-image {
            position: relative;
            width: 100%;
            height: 400px;
            overflow: hidden;
            border-radius: 12px;
            background: #f8f9fa;
        }

        .modal-product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 12px;
        }

        .modal-product-image .no-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f0f0f0;
            color: #999;
            font-size: 1.2rem;
            border-radius: 12px;
        }
    </style>

    <!-- Product Modal -->
    <div id="productModal" class="product-modal">
        <div class="modal-container">
            <span onclick="closeModal()" class="modal-close">&times;</span>
            <div id="modalContent"></div>
        </div>
    </div>

    <style>
        /* Modal Styles */
        .product-modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            animation: fadeIn 0.3s ease-out;
        }

        .product-modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            box-sizing: border-box;
        }

        .modal-container {
            position: relative;
            /* cukup relative */
            background-color: #fff;
            margin: 0;
            padding: 0;
            border-radius: 16px;
            width: 100%;
            max-width: 1000px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            animation: zoomIn 0.3s ease-out;
            /* ganti animasi */
        }

        @keyframes zoomIn {
            from {
                transform: scale(0.8);
                opacity: 0;
            }

            to {
                transform: scale(1);
                opacity: 1;
            }
        }

        .modal-close {
            position: absolute;
            top: 15px;
            right: 20px;
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            z-index: 1001;
            transition: color 0.2s ease;
        }

        .modal-close:hover,
        .modal-close:focus {
            color: #000;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        @keyframes slideIn {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }

            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @media (max-width: 768px) {
            .product-modal.show {
                padding: 10px;
            }

            .modal-container {
                width: 100%;
                max-height: 95vh;
            }

            .modal-close {
                top: 10px;
                right: 15px;
                font-size: 24px;
            }
        }
    </style>

    <div id="loadingOverlay" class="loading-overlay">
        <div class="loading-spinner"></div>
        <p>Memuat data...</p>
    </div>

    <script>
        // Data dari Blade disiapkan untuk JavaScript
        const allCategories = <?php echo json_encode($categories, 15, 512) ?>;
        const allSubcategories = <?php echo json_encode($subCategories, 15, 512) ?>;

        // Tenant Asset Helper Function
        const tenantAssetBase = "<?php echo e(url('tenancy/assets')); ?>/";

        const tenantAssetUrl = (p) => {
            let path = (p || '')
                .replace(/^storage\/+/i, '') // buang "storage/" kalau ada
                .replace(/^\/+/, '') // buang slash depan
                .replaceAll('\\', '/'); // normalize backslash Windows
            return tenantAssetBase + encodeURI(path);
        };

        // Legacy support - ASSET_URL for backward compatibility
        const ASSET_URL = tenantAssetBase;

        document.addEventListener('DOMContentLoaded', () => {
            // --- FUNGSI-FUNGSI UTAMA ---

            // Fungsi untuk mengarahkan pengguna dengan parameter filter
            function applyFilterAndReload() {
                const baseUrl = `<?php echo e(url()->current()); ?>`;
                const params = new URLSearchParams();

                // Kategori
                const activeCategory = document.querySelector('.category-card.active');
                if (activeCategory && activeCategory.dataset.categoryId !== 'all') {
                    params.set('category', activeCategory.dataset.categoryId);
                }

                // Subkategori
                const activeSubcategory = document.querySelector('.subcategory-card.active');
                if (activeSubcategory && activeSubcategory.dataset.subcategoryId) {
                    params.set('subcategory', activeSubcategory.dataset.subcategoryId);
                }

                // Pencarian
                const searchTerm = document.getElementById('searchInput').value;
                if (searchTerm) {
                    params.set('search', searchTerm);
                }

                // Urutan
                const sortPrice = document.getElementById('sortPrice').value;
                const sortName = document.getElementById('sortName').value;
                const sortDate = document.getElementById('sortDate').value;

                if (sortPrice) params.set('sort', sortPrice);
                else if (sortName) params.set('sort', sortName);
                else if (sortDate) params.set('sort', sortDate);

                window.location.href = `${baseUrl}?${params.toString()}`;
            }

            // Fungsi untuk menampilkan subkategori yang relevan
            function showSubcategoriesForCategory(categoryId) {
                const subcategoryGrid = document.getElementById('subcategoryGrid');
                const subcategorySection = document.getElementById('subcategorySection');
                subcategoryGrid.innerHTML = '';

                const relevantSubcategories = categoryId === 'all' ?
                    allSubcategories :
                    allSubcategories.filter(sub => sub.product_category_id == categoryId);

                if (relevantSubcategories.length === 0) {
                    subcategorySection.style.display = 'none';
                    return;
                }

                const allSubCard = document.createElement('div');
                allSubCard.className = 'subcategory-card active';
                allSubCard.innerHTML = '<div class="subcategory-name">Semua Sub Kategori</div>';
                allSubCard.onclick = () => selectSubcategory(null, allSubCard);
                subcategoryGrid.appendChild(allSubCard);

                relevantSubcategories.forEach(sub => {
                    const subCard = document.createElement('div');
                    subCard.className = 'subcategory-card';
                    subCard.dataset.subcategoryId = sub.id;
                    subCard.innerHTML = `<div class="subcategory-name">${sub.name}</div>`;
                    subCard.onclick = () => selectSubcategory(sub.id, subCard);
                    subcategoryGrid.appendChild(subCard);
                });

                subcategorySection.style.display = 'block';
            }

            function selectSubcategory(subcategoryId, element) {
                document.querySelectorAll('.subcategory-card').forEach(card => card.classList.remove('active'));
                element.classList.add('active');
                applyFilterAndReload();
            }

            // --- EVENT LISTENERS ---

            document.querySelectorAll('.category-card').forEach(card => {
                card.addEventListener('click', function() {
                    const categoryId = this.dataset.categoryId;
                    const currentUrl = new URL(window.location.href);
                    currentUrl.searchParams.delete(
                        'subcategory'); // Hapus subkategori saat ganti kategori utama
                    currentUrl.searchParams.delete('page'); // Kembali ke halaman 1
                    if (categoryId === 'all') {
                        currentUrl.searchParams.delete('category');
                    } else {
                        currentUrl.searchParams.set('category', categoryId);
                    }
                    window.location.href = currentUrl.toString();
                });
            });

            // Event listener untuk filter
            document.getElementById('searchInput').addEventListener('keypress', (e) => {
                if (e.key === 'Enter') applyFilterAndReload();
            });
            document.getElementById('sortPrice').addEventListener('change', applyFilterAndReload);
            document.getElementById('sortName').addEventListener('change', applyFilterAndReload);
            document.getElementById('sortDate').addEventListener('change', applyFilterAndReload);

            // --- INISIALISASI ---
            const currentUrlParams = new URLSearchParams(window.location.search);
            const currentCategory = currentUrlParams.get('category') || 'all';
            const currentSubcategory = currentUrlParams.get('subcategory');

            // Atur state aktif untuk kategori
            document.querySelectorAll('.category-card').forEach(c => c.classList.remove('active'));
            document.querySelector(`.category-card[data-category-id="${currentCategory}"]`).classList.add('active');

            // Tampilkan dan atur state aktif untuk subkategori
            if (currentCategory !== 'all') {
                showSubcategoriesForCategory(currentCategory);
                if (currentSubcategory) {
                    document.querySelectorAll('.subcategory-card').forEach(sc => sc.classList.remove('active'));
                    const activeSubCard = document.querySelector(
                        `.subcategory-card[data-subcategory-id="${currentSubcategory}"]`);
                    if (activeSubCard) activeSubCard.classList.add('active');
                }
            }
        });
    </script>

    
    <script>
        const productModal = document.getElementById('productModal');
        const modalContent = document.getElementById('modalContent');
        const loadingOverlay = document.getElementById('loadingOverlay'); // Ensure this is defined

        async function showProductDetails(productId) {
            try {
                const response = await fetch(`/api/products/${productId}`);
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();
                const product = data.product;

                if (!product) {
                    console.error('Product not found in API response');
                    loadingOverlay.style.display = 'none';
                    return;
                }

                // Coba beberapa kemungkinan field gambar
                const imagePath = product.image || (product.images && product.images.length > 0 ? product.images[0]
                    .image_path : null);
                const imageUrl = imagePath ? tenantAssetUrl(imagePath) :
                    'https://via.placeholder.com/200?text=No+Image';

                const formattedPrice = new Intl.NumberFormat('id-ID', {
                    style: 'currency',
                    currency: 'IDR',
                    minimumFractionDigits: 0
                }).format(product.price);

                const material = product.specification?.material || '';
                const sizes = product.specification?.sizes || [];
                const colors = product.specification?.colors || [];

                // Generate sizes HTML
                let sizesHTML = '';
                if (sizes && sizes.length > 0) {
                    sizesHTML = `
                        <div class="modal-section">
                            <h4>Ukuran Tersedia:</h4>
                            <div class="sizes-list">
                                ${sizes.map(size => `<span class="size-tag">${size}</span>`).join('')}
                            </div>
                        </div>
                    `;
                }

                // Generate colors HTML
                let colorsHTML = '';
                if (colors && colors.length > 0) {
                    colorsHTML = `
                        <div class="modal-section">
                            <h4>Warna Tersedia:</h4>
                            <div class="colors-list">
                                ${colors.map(color => `<span class="color-tag">${color}</span>`).join('')}
                            </div>
                        </div>
                    `;
                }

                modalContent.innerHTML = `
                    <div class="modal-product-details">
                        <div class="modal-product-image">
                            <img src="${imageUrl}"
                                 alt="${product.name}"
                                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
                                 style="width: 100%; height: 400px; object-fit: cover; border-radius: 12px;">
                            <div class="no-image" style="display: none; height: 400px; background: #f0f0f0; border-radius: 12px; align-items: center; justify-content: center; font-size: 1.2rem; color: #999;">📷 Image Not Available</div>
                        </div>
                        <div class="modal-product-info">
                            <div class="modal-product-category">${product.category?.name || 'Uncategorized'}${product.subcategory ? ' - ' + product.subcategory : ''}</div>
                            <h2 class="modal-product-name">${product.name}</h2>
                            <div class="modal-product-price">${formattedPrice}</div>
                            <div class="modal-product-description">
                                <h4>Deskripsi:</h4>
                                <p>${product.description || 'Tidak ada deskripsi.'}</p>
                            </div>
                            ${material ? `
                                                                                                        <div class="modal-section">
                                                                                                            <h4>Material:</h4>
                                                                                                            <p>${material}</p>
                                                                                                        </div>
                                                                                                    ` : ''}
                            ${sizesHTML}
                            ${colorsHTML}
                            ${product.stock ? `
                                                                                                        <div class="modal-section">
                                                                                                            <h4>Stok:</h4>
                                                                                                            <p class="stock-info ${product.stock > 10 ? 'in-stock' : product.stock > 0 ? 'low-stock' : 'out-of-stock'}">
                                                                                                                ${product.stock > 0 ? `${product.stock} unit tersedia` : 'Stok habis'}
                                                                                                            </p>
                                                                                                        </div>
                                                                                                    ` : ''}
                        </div>
                    </div>

                    <style>
                        .modal-product-details {
                            display: grid;
                            grid-template-columns: 1fr 1fr;
                            gap: 2rem;
                            padding: 2rem;
                        }

                        .modal-product-category {
                            font-size: 0.9rem;
                            color: #777;
                            text-transform: uppercase;
                            letter-spacing: 1px;
                            margin-bottom: 0.5rem;
                        }

                        .modal-product-name {
                            font-size: 2rem;
                            font-weight: 700;
                            color: #333;
                            margin-bottom: 1rem;
                            line-height: 1.2;
                        }

                        .modal-product-price {
                            font-size: 1.8rem;
                            font-weight: 700;
                            color: #999;
                            margin-bottom: 1.5rem;
                        }

                        .modal-section {
                            margin-bottom: 1.5rem;
                        }

                        .modal-section h4 {
                            font-size: 1.1rem;
                            font-weight: 600;
                            color: #333;
                            margin-bottom: 0.5rem;
                        }

                        .modal-section p {
                            line-height: 1.6;
                            color: #555;
                        }

                        .sizes-list, .colors-list {
                            display: flex;
                            flex-wrap: wrap;
                            gap: 0.5rem;
                        }

                        .size-tag, .color-tag {
                            background: #f0f0f0;
                            padding: 0.4rem 0.8rem;
                            border-radius: 20px;
                            font-size: 0.9rem;
                            font-weight: 500;
                            border: 1px solid #ddd;
                        }

                        .stock-info.in-stock { color: #28a745; }
                        .stock-info.low-stock { color: #ffc107; }
                        .stock-info.out-of-stock { color: #dc3545; }

                        @media (max-width: 768px) {
                            .modal-product-details {
                                grid-template-columns: 1fr;
                                gap: 1rem;
                                padding: 1rem;
                            }

                            .modal-product-name {
                                font-size: 1.5rem;
                            }

                            .modal-product-price {
                                font-size: 1.4rem;
                            }
                        }
                    </style>
                `;

                productModal.classList.add('show');
                document.body.style.overflow = 'hidden';

            } catch (error) {
                console.error('Error fetching product details:', error);
                alert('Gagal memuat detail produk. Silakan coba lagi.');
            }
        }

        // Close modal
        function closeModal() {
            productModal.classList.remove('show');
            document.body.style.overflow = 'auto';
        }

        // Close modal when clicking outside
        productModal.addEventListener('click', function(event) {
            if (event.target === productModal) {
                closeModal();
            }
        });

        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && productModal.style.display === 'block') {
                closeModal();
            }
        });

        // Hero Slider Script
        document.addEventListener('DOMContentLoaded', () => {
            const sliderWrapper = document.getElementById('slider-wrapper');
            const prevBtn = document.querySelector('.slider-nav.prev');
            const nextBtn = document.querySelector('.slider-nav.next');
            const indicatorsContainer = document.getElementById('slider-indicators');
            const slides = document.querySelectorAll('.slide');
            const totalSlides = slides.length;
            let currentIndex = 0;
            let slideInterval;

            function updateSlider() {
                const offset = -currentIndex * 100;
                sliderWrapper.style.transform = `translateX(${offset}%)`;

                const indicators = document.querySelectorAll('.slider-indicator');
                indicators.forEach((indicator, index) => {
                    indicator.classList.toggle('active', index === currentIndex);
                });
            }

            function goToNextSlide() {
                currentIndex = (currentIndex + 1) % totalSlides;
                updateSlider();
            }

            function startAutoplay() {
                slideInterval = setInterval(goToNextSlide, 5000);
            }

            function stopAutoplay() {
                clearInterval(slideInterval);
            }

            nextBtn.addEventListener('click', () => {
                stopAutoplay();
                goToNextSlide();
                startAutoplay();
            });

            prevBtn.addEventListener('click', () => {
                stopAutoplay();
                currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
                updateSlider();
                startAutoplay();
            });

            startAutoplay();
        });
    </script>

</body>

</html>
<?php /**PATH D:\laragon\www\katalogku\resources\views/tenant/template/fashion/index.blade.php ENDPATH**/ ?>
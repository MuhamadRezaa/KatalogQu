<footer class="footer">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12 footer-copyright text-center">
        <p class="mb-0">
            Copyright <?php echo e(date('Y')); ?> © 
            <?php if(isset($userStore) && $userStore->store_name): ?>
                <?php echo e($userStore->store_name); ?>

            <?php else: ?>
                Store Admin Panel
            <?php endif; ?>
            | Powered by KatalogQu
        </p>
      </div>
    </div>
  </div>
</footer><?php /**PATH D:\laragon\www\katalogku\resources\views/tenant/admin/layouts/footer.blade.php ENDPATH**/ ?>